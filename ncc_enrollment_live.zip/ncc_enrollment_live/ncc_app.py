from flask import Flask, request, redirect, render_template_string, session
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # change before deploying

# --- Database Setup ---
def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            fname TEXT,
            mname TEXT,
            rollno TEXT,
            mobile TEXT,
            class TEXT,
            address TEXT
        )
    ''')
    conn.commit()
    conn.close()

# --- HTML Templates ---

form_html = '''<!DOCTYPE html>
<html>
<head>
    <title>CRM JAT COLLEGE NEW NCC ENROLLMENT 2025-26</title>
    <style>
        body { font-family: Arial; background: #eef; padding: 10px; margin: 0; }
        h1 { text-align: center; font-size: 1.5em; }

        form {
            max-width: 95%%;
            margin: auto;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        input, textarea {
            width: 100%%;
            padding: 12px;
            margin: 8px 0;
            border-radius: 5px;
            border: 1px solid #aaa;
            font-size: 1em;
        }
        button {
            background-color: #003366;
            color: white;
            padding: 12px;
            width: 100%%;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }
        button:hover { background-color: #0055aa; }

        @media (max-width: 600px) {
            h1 { font-size: 1.2em; }
            input, textarea, button { font-size: 0.9em; }
        }
    </style>
</head>
<body>
    <h1>CRM JAT COLLEGE NEW NCC ENROLLMENT 2025-26</h1>
    <form method="POST">
        <input type="text" name="name" placeholder="Student Name" required>
        <input type="text" name="fname" placeholder="Father's Name" required>
        <input type="text" name="mname" placeholder="Mother's Name" required>
        <input type="text" name="rollno" placeholder="Roll Number" required>
        <input type="text" name="mobile" placeholder="Mobile Number" required>
        <input type="text" name="class" placeholder="Class" required>
        <textarea name="address" placeholder="Address" required></textarea>
        <br>
        <button type="submit">Submit</button>
    </form>
</body>
</html>'''

thank_you_html = '''<!DOCTYPE html>
<html>
<head><title>Thank You</title></head>
<body style="text-align: center; font-family: Arial; background-color: #ddf;">
    <h1>Thank you for submitting your details!</h1>
    <p>Your form has been successfully submitted for NCC Enrollment.</p>
    <a href="/">Submit another response</a>
</body>
</html>'''

login_html = '''<!DOCTYPE html>
<html>
<head><title>Admin Login</title></head>
<body style="text-align: center; font-family: Arial; background-color: #eef; padding: 20px;">
    <h2>Admin Login</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <button type="submit">Login</button>
    </form>
    {% if error %}<p style="color:red;">{{ error }}</p>{% endif %}
</body>
</html>'''

admin_panel_html = '''<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel - NCC Submissions</title>
    <style>
        body { font-family: Arial; background: #f7f7f7; padding: 10px; }
        h2 { text-align: center; font-size: 1.4em; }
        a.logout { float: right; }

        .table-container { overflow-x: auto; }

        table { 
            width: 100%%; 
            border-collapse: collapse; 
            background: white;
            font-size: 0.9em;
        }
        th, td { 
            padding: 8px; 
            border: 1px solid #ccc; 
            text-align: left; 
            word-break: break-word;
        }

        @media (max-width: 600px) {
            h2 { font-size: 1.1em; }
            table { font-size: 0.8em; }
        }
    </style>
</head>
<body>
    <h2>Admin Panel - NCC Enrollment Submissions <a class="logout" href="/logout">Logout</a></h2>
    <div class="table-container">
    <table>
        <tr>
            <th>ID</th><th>Name</th><th>Father's Name</th><th>Mother's Name</th>
            <th>Roll No</th><th>Mobile</th><th>Class</th><th>Address</th>
        </tr>
        {% for student in students %}
        <tr>
            <td>{{ student[0] }}</td>
            <td>{{ student[1] }}</td>
            <td>{{ student[2] }}</td>
            <td>{{ student[3] }}</td>
            <td>{{ student[4] }}</td>
            <td>{{ student[5] }}</td>
            <td>{{ student[6] }}</td>
            <td>{{ student[7] }}</td>
        </tr>
        {% endfor %}
    </table>
    </div>
</body>
</html>'''

# --- Routes ---

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        data = (
            request.form['name'],
            request.form['fname'],
            request.form['mname'],
            request.form['rollno'],
            request.form['mobile'],
            request.form['class'],
            request.form['address']
        )
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute('''
            INSERT INTO students (name, fname, mname, rollno, mobile, class, address)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', data)
        conn.commit()
        conn.close()
        return redirect('/thankyou')
    return render_template_string(form_html)

@app.route('/thankyou')
def thank_you():
    return render_template_string(thank_you_html)

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    error = None
    if request.method == 'POST':
        if request.form['username'] == 'admin' and request.form['password'] == 'admin123':
            session['admin_logged_in'] = True
            return redirect('/adminpanel')
        else:
            error = 'Invalid credentials'
    return render_template_string(login_html, error=error)

@app.route('/adminpanel')
def admin_panel():
    if not session.get('admin_logged_in'):
        return redirect('/admin')
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('SELECT * FROM students')
    students = c.fetchall()
    conn.close()
    return render_template_string(admin_panel_html, students=students)

@app.route('/logout')
def logout():
    session.pop('admin_logged_in', None)
    return redirect('/admin')

# --- Run App ---
if __name__ == '__main__':
    init_db()
    app.run(debug=True)
